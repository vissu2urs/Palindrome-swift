//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func checkForPalendrome(word:String) -> Bool {
    
    var charsGroup:[Character] = [Character]()
    for  object in word {
        charsGroup.append(object)
    }
    for (i, char) in charsGroup.enumerated() where i <= charsGroup.count/2 {
        if char != charsGroup[(charsGroup.count - (i+1))] {
            return false
        }
    }
    return true
}

print(checkForPalendrome(word: "abhhhba"))
print(checkForPalendrome(word: "aba"))
print(checkForPalendrome(word: "sda"))

//

func checkForPalen(word:String) -> Bool {
    let stringReverse = String(word.reversed())
    if word != stringReverse {
        return false
    }
    return true
    
}

print(checkForPalen(word: "abhhhba"))
print(checkForPalen(word: "abka"))
print(checkForPalen(word: "sda"))

func checkForPalen2(word:String) -> Bool {
    var strReverse = ""
    for character in word{
        strReverse = "\(character)" + strReverse
        print ( strReverse)
    }
    if word != strReverse {
        return false
    }
    return true
}
print(checkForPalen2(word: "abhhhba"))
print(checkForPalen2(word: "abka"))
print(checkForPalen2(word: "sda"))


func checkForPalen3(word:String) -> Bool {
    var reversedWord = [Character]()
    for obj in word{
        reversedWord.insert(obj, at: 0)
    }
    let strReverse = String(reversedWord)
    if word != strReverse {
        return false
    }
    return true
}
print(checkForPalen2(word: "abhhhba"))
print(checkForPalen2(word: "abka"))
print(checkForPalen2(word: "sda"))
